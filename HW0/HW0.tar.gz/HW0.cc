//
//  HW0
//  Farhan Haziq
//  fargah1@cs.colostate.edu
//  August 25th, 2020
//

#include <iostream>

int main()
{
    //“How many CU students does it take to change a light bulb?” 
    std::cout << "TThree—one to hold the light bulb and two to complain why you should use 100% organic-certified smart lightbulb from Amazon instead of using generic lightbulb from Wal-Mart !." << std::endl;
    return 0;
}